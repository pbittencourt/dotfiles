#!/bin/sh
sed -i \
         -e 's/#fffbef/rgb(0%,0%,0%)/g' \
         -e 's/#5c6a72/rgb(100%,100%,100%)/g' \
    -e 's/#fffbef/rgb(50%,0%,0%)/g' \
     -e 's/#dfa000/rgb(0%,50%,0%)/g' \
     -e 's/#fffbef/rgb(50%,0%,50%)/g' \
     -e 's/#5c6a72/rgb(0%,0%,50%)/g' \
	"$@"
