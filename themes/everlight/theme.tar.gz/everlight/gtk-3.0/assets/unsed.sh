#!/bin/sh
sed -i \
         -e 's/rgb(0%,0%,0%)/#fffbef/g' \
         -e 's/rgb(100%,100%,100%)/#5c6a72/g' \
    -e 's/rgb(50%,0%,0%)/#fffbef/g' \
     -e 's/rgb(0%,50%,0%)/#dfa000/g' \
 -e 's/rgb(0%,50.196078%,0%)/#dfa000/g' \
     -e 's/rgb(50%,0%,50%)/#fffbef/g' \
 -e 's/rgb(50.196078%,0%,50.196078%)/#fffbef/g' \
     -e 's/rgb(0%,0%,50%)/#5c6a72/g' \
	"$@"
